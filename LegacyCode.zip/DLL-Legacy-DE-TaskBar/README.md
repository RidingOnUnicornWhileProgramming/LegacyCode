# DE-TaskBar
TaskBar used in DE
After The Build, place it in rsc/Plugins folder. You'll need also DE-API and DE-WindowManagement in there. 
You can find these on My Account.
Icon Extractor is a property of Tsuda Kageyu https://github.com/TsudaKageyu , kudos to him!
