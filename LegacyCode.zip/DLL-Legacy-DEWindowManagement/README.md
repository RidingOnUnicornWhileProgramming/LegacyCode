# DEWindowManagement
Library for WindowManagement in windows. Just wrapper arround WINAPI
Main Project is DE (name is going to be changed... in the future)
Main work by Paweł Zmarzły (pzmarzly) Kudos to him!!!

