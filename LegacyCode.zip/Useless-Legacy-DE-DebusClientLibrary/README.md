# DE-DebusClientLibrary
current version of DebusClientLibrary.cs

## Installation
- download the file and add it to your project
- using NuGet, download SuperSocket.ClientEngine and its dependencies

## Usage
Check out https://github.com/pzmarzly/DE-Example1, https://github.com/pzmarzly/DE-Terminal and other projects.
