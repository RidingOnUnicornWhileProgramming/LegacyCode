# WinDE-Windows Desktop Environment
Windows Desktop Environment Written using C# and WPF. Some of the code derrived from Merula Shell,modified by to work with current Windows Systems
# Are you tired of seeing same laggy desktop everyday? We're trying to change it! 
With WinDE you are able to change your boring System's and reduce ram usage by your old and ugly explorer shell.
If you want to help, or you have some ideas that might help us. You can reach us somehow. 
# Important Note
We started. It's not complete project so use it carefully. 
# HOW TO MAKE PLUGINS
To make plugins you need to compile and Include in your references API for WinDE (It's a single interface) 
So, make a class. implement interface and provide all the data excluding enabled, This is a future feature. To see how plugin works, take a look at DE-Taskbar. 
App looks for them in
<code>{appRoot}/rsc/Plugins</code>

